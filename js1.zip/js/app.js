// Register a new user
async function registerUser(username, email, password) {
    try {
        const response = await fetch('http://localhost:5002/api/users/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, email, password })
        });
        const data = await response.json();
        
        if (response.ok) {
            alert('Registration successful!');
        } else {
            alert('Error: ' + data.message);
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

// Log in the user and save the token
async function loginUser(email, password) {
    try {
        const response = await fetch('http://localhost:5002/api/users/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        const data = await response.json();
        
        if (response.ok) {
            localStorage.setItem('token', data.token); // Save the token for future requests
            alert('Login successful!');
        } else {
            alert('Error: ' + data.message);
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

// Cast a vote for a candidate
async function castVote(candidate) {
    try {
        const token = localStorage.getItem('token'); // Get the token from local storage
        const response = await fetch('http://localhost:5002/api/votes/cast', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}` // Send the token for authentication
            },
            body: JSON.stringify({ candidate })
        });
        const data = await response.json();
        
        if (response.ok) {
            alert('Vote cast successfully!');
        } else {
            alert('Error: ' + data.message);
        }
    } catch (error) {
        console.error('Error:', error);
    }
}
