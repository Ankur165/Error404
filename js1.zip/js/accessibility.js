// JavaScript for Font Sizing
function adjustFontSize(change) {
    const elements = document.querySelectorAll('body, body *');
    elements.forEach(element => {
      const currentSize = window.getComputedStyle(element, null).getPropertyValue('font-size');
      const newSize = parseFloat(currentSize) + change;
      element.style.fontSize = `${newSize}px`;
    });
  }
  
  // JavaScript for Contrast Toggle
  function toggleContrast() {
    document.body.classList.toggle('high-contrast');
  }
  